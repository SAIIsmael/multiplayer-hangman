#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

#define BUF_SIZE 10000

int main (int argc, char * argv[])
{
    key_t key;
    int sem;
    int shm;

    if ((key = ftok("server", 0)) == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }

    if (((sem = semget(key, 1, 0)) == -1)
    || ((shm = shmget(key, BUF_SIZE, 0)) == -1) ) {
        perror("semget/shmget");
        exit(EXIT_FAILURE);
    }
    // Supprimer la memoire partagée
    if (shmctl(shm, IPC_RMID, NULL) == -1) {
        perror("shmctl");
        exit(EXIT_FAILURE);
    }

    // Supprimer les semaphores
    if (semctl(sem, 0, IPC_RMID) == -1) {
        perror("semctl");
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
}
