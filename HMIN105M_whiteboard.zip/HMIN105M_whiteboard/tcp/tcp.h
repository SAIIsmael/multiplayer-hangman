#ifndef TCP_H
#define TCP_H

#define CHUNK_SIZE 6000

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

int tcp_send(int sock, char* buff, int nboctets);
int tcp_rcv(int sock, char* buff, int nboctets);
#endif
