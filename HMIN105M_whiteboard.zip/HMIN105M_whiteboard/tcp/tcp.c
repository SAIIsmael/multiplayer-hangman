#include "tcp.h"

int tcp_send(int sock, char *buff, int nboctets)
{
    int deja_envoyes = 0, envoi, a_envoyer = nboctets;

    while (deja_envoyes < nboctets){
        envoi = send(sock, buff + deja_envoyes, a_envoyer, 0);
        if (envoi == -1) {
            fprintf(stderr, "\n\033[31merreur send : %s\033[0m\n\n", strerror(errno));
            return -1;
        }

        deja_envoyes += envoi;
        a_envoyer -= envoi;
    }
    return deja_envoyes;
}


int tcp_rcv(int sock, char *buff, int nboctets)
{
    int deja_recu = 0;
    int a_recevoir = nboctets;
    int reception;

    if (nboctets < CHUNK_SIZE) { //buff+deja_recu ne marchera que si nboctets < taille buff
        while ((deja_recu < nboctets)) {
            reception = recv(sock, buff+deja_recu,a_recevoir,0);
            if (reception == -1) {
                fprintf(stderr, "\n\033[31merreur rcv  : %s\033[0m\n\n", strerror(errno));
                return -1;
            } else if (reception == 0) {
                printf("\nLE CLIENT S\'EST DECONNECTE...\n");
                return 0;
            }

            deja_recu += reception;
            a_recevoir -= reception;
        }

        return deja_recu;
    }

    reception = recv(sock, buff+deja_recu,a_recevoir,0);
    if (reception == -1) {
        fprintf(stderr, "\n\033[31merreur rcv  : %s\033[0m\n\n", strerror(errno));
        return -1;
    } else if (reception == 0) {
        printf("\nLE CLIENT S\'EST DECONNECTE...\n");
        return 0;
    }

    return deja_recu+reception;
}
