#ifndef __UTILITIES_H
#define __UTILITIES_H

#define BUF_SIZE 10000

#define BLU "\x1b[34m"
#define YEL "\033[32m"
#define NRM "\033[0m"

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

typedef union semun
{
    int val;
    struct semid_ds * buffer;
    unsigned short int * table;
} semun_t;

// Structure contenant la socket du client et son adresse IP
typedef struct client_info
{
    int cfd;
    char ip[16];
} client_i;

// Structure contenant la mémoire partagée
typedef struct sh_mem_t
{
    int shm;
    char buffer[BUF_SIZE]; // contenu de la memoire
} sh_mem;

#endif
