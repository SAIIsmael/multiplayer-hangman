#ifndef _SEM_FUNCTIONS_H_
#define _SEM_FUNCTIONS_H_

#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/types.h>

int P(int id, struct sembuf *buffer)
{
    buffer->sem_num = 0;
    buffer->sem_op  = -1;
    buffer->sem_flg = SEM_UNDO;
    return semop(id, buffer, 1);
}

int V(int id, struct sembuf *buffer)
{
    buffer->sem_num = 0;
    buffer->sem_op  = 1;
    buffer->sem_flg = SEM_UNDO;
    return semop(id, buffer, 1);
}

#endif
