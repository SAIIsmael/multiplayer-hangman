#include <arpa/inet.h>
#include <errno.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/time.h> // Pour gettimeofday() et faire par exemple un "modifié le .."
#include <unistd.h>

#include "sem_functions.h"
#include "utilities.h"

int sem;
sh_mem shmem;
struct sembuf sembuf;

void * receiveContentFromClient(void *arg)
{
    client_i client = *((client_i*)arg);
    int bytesReceived;
    char *buf_shm = NULL;
    char buf_recv[500];

    if ((buf_shm = shmat(shmem.shm, NULL, 0)) == NULL) {
        error("shmat");
    }

    while (1) {
        // Réception des modifications
        bytesReceived = recv(client.cfd, buf_recv, BUF_SIZE, 0);
        if (bytesReceived == 0) {
            printf(YEL "\nDéconnection du client %s \n" NRM, client.ip);
            exit(EXIT_FAILURE);
        } else if (bytesReceived == -1) {
            error("recv");
        }

        // Déblocage de la mémoire partagée
        if (V(sem, &sembuf) < 0) {
            error("semop");
        }

        // Puis écriture dans la mémoire partagée
        strcat(buf_shm, buf_recv);
        printf("\033c"); // Nettoyer le terminal
        printf(BLU "%s" NRM, client.ip);
        printf(" > %s", buf_shm);

        // Blocage de la mémoire partagée
        if (P(sem, &sembuf) < 0) {
            error("semop");
        }
    }

    pthread_exit(buf_shm);
}

void * sendContentToClient(void *arg)
{
    client_i client = *((client_i*)arg);
    int contentBytesSent;
    char *buf = NULL;

    // Attachement du segment en lecture seule
    if ((buf = shmat(shmem.shm, NULL, SHM_RDONLY)) == NULL) {
        error("shmat");
    }

    while (1) {
        // Blocage de la mémoire partagée
        if (P(sem, &sembuf) < 0) {
            error("semop");
        }

        // Envoi du contenu de la mémoire partagée
        contentBytesSent = send(client.cfd, buf, BUF_SIZE, 0);
        if (contentBytesSent == -1) {
            error("send");
        }

        // Déblocage de la mémoire partagée
        if (V(sem, &sembuf) < 0) {
            error("semop");
        }
    }

    pthread_exit(buf);
}

int main(int argc, char const *argv[]) {
    int sfd, cfd, contentBytesSent, enable;
    key_t key;
    pid_t pid;
    pthread_t threadRecv;
    pthread_t threadSend;
    client_i client;
    char welcome[BUF_SIZE + 30];
    void *ptr;

    struct sockaddr_in srv_addr, clt_addr;
    socklen_t clt_addr_size;

    if (argc != 2) {
        fprintf(stderr, "Usage : %s <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if ((key = ftok("server", 0)) == -1) {
        error("ftok");
    }

    // Créer la mémoire partagée
    if ((shmem.shm = shmget(key, BUF_SIZE, IPC_CREAT | 0600)) == -1) {
        error("shmget");
    }

    /* Créer l'ensemble de semaphores
    *  pour que plusieurs client puissent modifier le contenu en même temps
    */
    if ((sem = semget(key, 1, IPC_CREAT | IPC_EXCL | 0600)) == -1) {
        error("shmget");
    }

    memset(&srv_addr, 0, sizeof(srv_addr));
    srv_addr.sin_family = AF_UNSPEC;          // Nommage de la famille de socket
    srv_addr.sin_addr.s_addr = INADDR_ANY;    // Adresse de la socket
    srv_addr.sin_port = htons(atoi(argv[1])); // Récupération du numero de port avec conversion en réseau du numero de port grace à htons

    sfd = socket(PF_INET, SOCK_STREAM, 0);
    if (sfd == -1) {
        error("socket");
    }

    // Pour réutiliser la socket sur le même port
    if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0) {
        error("setsockopt(SO_REUSEADDR) failed");
    }

    if (bind(sfd, (struct sockaddr*)&srv_addr, sizeof(srv_addr)) == -1) {
        error("bind");
    }

    if (listen(sfd, 128) == -1) {
        error("listen");
    }


    printf("\n=========================================\n");
    printf("|                 SERVEUR               |\n");
    printf("=========================================\n");

    while (1) {
        clt_addr_size = sizeof(struct sockaddr_in);
        cfd = accept(sfd, (struct sockaddr *) &clt_addr, &clt_addr_size);

        if (cfd == -1) {
            close(cfd);
            error("accept");
        }

        client.cfd = cfd;
        strcpy(client.ip, inet_ntoa(clt_addr.sin_addr)); // Récupérer l'adresse IP du client

        printf(YEL "\nConnexion du client %s\n\n" NRM, client.ip);

        if ((pid = fork()) == -1) {
            error("fork");
        } else if (pid == 0) { // processus fils

            /* Concaténation d'un message de bienvenue et du contenu */
            strcpy(welcome, YEL "Bienvenue sur l'espace partagé ");
            strcat(welcome, client.ip);
            strcat(welcome, " !\n" NRM);

            char *buf;
            if ((buf = shmat(shmem.shm, NULL, 0)) == NULL) {
                error("shmat");
            }

            strcat(welcome, buf);
            strcat(welcome, "\n> ");

            contentBytesSent = send(client.cfd, welcome, BUF_SIZE, 0);
            if (contentBytesSent == -1) {
                error("send");
            }

            if (pthread_create(&threadRecv, NULL, receiveContentFromClient, &client) != 0) {
                error("pthread_create - threadRecv");
            }
            //
            // if (pthread_create(&threadSend, NULL, sendContentToClient, &client) != 0) {
            //     error("pthread_create - threadSend");
            // }
            //
            // if (pthread_join(threadRecv, &ptr) != 0) {
            //     error("pthread_join - threadRecv");
            // }
            //
            // if (pthread_join(threadSend, NULL) != 0) {
            //     error("pthread_join - threadSend");
            // }
        }
    }

    close(cfd);
    close(sfd);

    return EXIT_SUCCESS;
}
