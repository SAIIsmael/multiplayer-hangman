### Projet Whiteboard (Espace blanc collaboratif)

#### Compilation

Pour compiler, allez dans le répertoire racine du projet et lancez

    $ make

#### Exécution

Pour exécuter ouvrez deux terminaux, l'un dans lequel vous lancerez le serveur :

    $ ./server <port>

Et un autre dans lequel vous lancerez un client :

    $ ./client <ip_serveur> <port>

#### Messages

`shmget: File exists` -> il faut supprimer la mémoire partagée :

    $ ./delete
