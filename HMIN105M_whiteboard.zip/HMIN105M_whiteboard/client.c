#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "sem_functions.h"
#include "utilities.h"

// Contenu partagé
char buffer[BUF_SIZE];

void * writeThread(void *arg)
{
    int sfd = *((int*)arg);
    int bytesSent;
    char buf[500], *getsRet;

    while (1) {
        /* Saisie du contenu */
        getsRet = fgets(buf, BUF_SIZE, stdin);
        if (getsRet == NULL) {
            fprintf(stderr, "fgets");
            exit(EXIT_FAILURE);
        }

        bytesSent = send(sfd, buf, BUF_SIZE, 0);
        if (bytesSent == -1) {
            error("send");
        } else if (bytesSent == 0) {
            fprintf(stderr, "writeThread, bytesSent = 0)\n");
            exit(EXIT_FAILURE);
        }
    }

    pthread_exit(buf);
}

void * readThread(void *arg)
{
    int sfd = *((int*)arg);
    int bytesReceived;

    while (1) {
        /* Réception des modifications */
        bytesReceived = recv(sfd, buffer, BUF_SIZE * sizeof(char), 0);
        if (bytesReceived == -1) {
            perror("readThread recv");
            exit(EXIT_FAILURE);
        } else if (bytesReceived == 0) {
            printf(YEL "\nServeur arrêté.\n\n" NRM);
            exit(EXIT_SUCCESS);
        }

        system("clear"); // Nettoyer le terminal
        printf("%s\n> ", buffer);
    }

    pthread_exit(buffer);
}

int main(int argc,char** argv)
{
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    int sfd, getaddr_stat, bytesReceived;
    pthread_t thread_wr, thread_rd;

    if (argc != 3) {
        fprintf(stderr, "Usage : %s <host> <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC;     // Autoriser les IPv4 ou les IPv6
    hints.ai_socktype = SOCK_STREAM; // Socket en mode stream
    hints.ai_flags = 0;
    hints.ai_protocol = 0;           // N'importe quel protocole

    getaddr_stat = getaddrinfo(argv[1], argv[2], &hints, &result);
    if (getaddr_stat != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(getaddr_stat));
        exit(EXIT_FAILURE);
    }

    /* Récupération des adresses (ou d'une adresse) qui correspond au couple hôte/port */

    /* getaddrinfo() retourne une liste de structures d'adresses.
    On teste chaque adresse jusqu'à ce que connect() fonctionne.
    Si socket() ou connect() échoue, on ferme la socket et on essaie
    l'adresse suivante. */

    for (rp = result; rp != NULL; rp = rp->ai_next) {
        sfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sfd == -1) {
            continue;
        }

        if (connect(sfd, rp->ai_addr, rp->ai_addrlen) != -1) {
            break; // Connexion réussie
        }

        close(sfd);
    }

    if (rp == NULL) { // Aucune adresse trouvée
        fprintf(stderr, "Could not connect to the server\n");
        exit(EXIT_FAILURE);
    }

    freeaddrinfo(result); // On a plus besoin de result

    /* Réception des modifications */
    bytesReceived = recv(sfd, buffer, BUF_SIZE * sizeof(char), 0);
    if (bytesReceived == -1) {
        error("recv");
    }

    printf("%s", buffer);

    if (pthread_create(&thread_rd, NULL, readThread, &sfd) != 0) {
        error("pthread_create - readThread");
    }

    if (pthread_create(&thread_wr, NULL, writeThread, &sfd) != 0) {
        error("pthread_create - writeThread");
    }

    if (pthread_join(thread_wr, NULL) != 0) {
        error("pthread_join - writeThread");
    }

    if (pthread_join(thread_rd, NULL) != 0) {
        error("pthread_join - readThread");
    }

    return EXIT_SUCCESS;
}
